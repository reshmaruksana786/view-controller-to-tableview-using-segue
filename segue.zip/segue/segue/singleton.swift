//
//  singleton.swift
//  segue
//
//  Created by Sagi Harika on 1/30/20.
//  Copyright © 2020 Sagi Harika. All rights reserved.
//

import UIKit

class singleton: NSObject {
    static var shared = singleton()
    var name1=[String]()
    var imageStored=[UIImageView]()
    

}
